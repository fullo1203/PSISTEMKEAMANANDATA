<?php
session_start();
?>
<html>

<head>
    <title>tim dashboard</title>
</head>

<body>

    <div style="text-align:center">
        <h2>tim dashboard</h2>
        <p><a href="index.php">Home</a> / <a href="logout.php">Logout</a></p>

        <p>Selamat datang di tim dashboard, Anda Login dengan username <?php echo $_SESSION['member']; ?></p>
    </div>

</body>

</html>