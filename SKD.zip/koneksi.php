<?php
$conn=mysqli_connect("localhost", "root", "", "Frendly_match");

//check connection
if (mysqli_connect_errno()){
    echo "data tim eror : ".mysqli_connect_error();
}