<?php
session_start();
?>
<html>

<head>
    <title>Admin dashboard</title>
</head>

<body>

    <div style="text-align:center">
        <h2>Admin dashboard</h2>
        <p><a href="index.php">Home</a> / <a href="logout.php">Logout</a></p>

        <p>Selamat datang di Admin dashboard, Anda Login dengan Username <?php echo $_SESSION['admin']; ?></p>
    </div>

</body>

</html>