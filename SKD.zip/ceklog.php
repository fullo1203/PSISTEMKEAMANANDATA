<?php
require "koneksi.php";

session_start();

if(isset($_POST['login'])) {
$user = $_POST['Username'];
$pass = $_POST['Password'];

$data = mysqli_query($conn, "SELECT role FROM data_login where username='$user' AND password = '$pass'");
    if (mysqli_num_rows($data) == 0) {
    echo
    '<script>alert("Username atau Password yang Anda Masukkan Salah!"); document.location="index.php";</script>';
} else {
    $row = mysqli_fetch_assoc($data);
    if ($row['role'] == "admin") {
        $_SESSION['admin'] = $user;
        echo '<script language="javascript">alert("Anda berhasil Login Admin!"); document.location="admin.php";</script>';
    } else {
        $_SESSION['member'] = $user;
        echo '<script language="javascript">alert("Anda berhasil Login Member!"); document.location="tim.php";</script>';
    }
}
}