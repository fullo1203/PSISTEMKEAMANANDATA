function runScript(e) {
    if (e.keyCode == 32) {
    return false
    }
    else
    {
    return true;
    }
    }